import { qs } from "./helpers.js";

export function bindCine(triggerId, modalId, closeId, imgId) {
    const trigger = qs(triggerId);
    const modal = qs(modalId);
    const close = qs(closeId);

    if (!trigger || !modal || !close) return;

    trigger.onclick = () => modal.style.display = "block";
    close.onclick = () => modal.style.display = "none";
}
